%dw 2.0
output application/json
---
{
  "test-customer-registration-processing-flow-success": {
  customerId: 'CUST001',
  firstName: 'John',
  lastName: 'Doe',
  email: 'john.doe@gmail.com',
  phone: '9876543210',
  service: 'Premium',
  city: 'New York'
},
  "test-check-existing-customer-no-duplicate": {
  customerId: 'CUST001'
},
  "test-insert-new-customer-success": {
  customerId: 'CUST001',
  firstName: 'John',
  lastName: 'Doe',
  fullName: 'JOHN DOE',
  email: 'john.doe@gmail.com',
  emailDomain: 'gmail.com',
  phone: '9876543210',
  service: 'Premium',
  city: 'New York',
  customerType: 'REGULAR'
}
}
