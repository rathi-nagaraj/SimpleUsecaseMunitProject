%dw 2.0
output application/json
---
{
  "test-customer-registration-processing-flow-success": {
  "customerId": "CUST001",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "1234567890",
  "service": "Premium Insurance",
  "city": "New York"
},
  "test-customer-registration-processing-flow-vip-customer": {
  "customerId": "CUST002",
  "firstName": "Jane",
  "lastName": "Smith",
  "email": "jane.smith@company.com",
  "phone": "9876543210",
  "service": "Premium Insurance",
  "city": "Los Angeles"
},
  "test-customer-registration-processing-flow-other-customer-type": {
  "customerId": "CUST003",
  "firstName": "Bob",
  "lastName": "Johnson",
  "email": "bob.johnson@example.org",
  "phone": "5551234567",
  "service": "Basic Insurance",
  "city": "Chicago"
},
  "test-customer-registration-processing-flow-missing-customer-id": {
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "1234567890",
  "service": "Premium Insurance",
  "city": "New York"
},
  "test-customer-registration-processing-flow-missing-first-name": {
  "customerId": "CUST001",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "1234567890",
  "service": "Premium Insurance",
  "city": "New York"
},
  "test-customer-registration-processing-flow-missing-last-name": {
  "customerId": "CUST001",
  "firstName": "John",
  "email": "john.doe@gmail.com",
  "phone": "1234567890",
  "service": "Premium Insurance",
  "city": "New York"
},
  "test-customer-registration-processing-flow-invalid-email": {
  "customerId": "CUST001",
  "firstName": "John",
  "lastName": "Doe",
  "email": "invalid-email-format",
  "phone": "1234567890",
  "service": "Premium Insurance",
  "city": "New York"
},
  "test-customer-registration-processing-flow-missing-email": {
  "customerId": "CUST001",
  "firstName": "John",
  "lastName": "Doe",
  "phone": "1234567890",
  "service": "Premium Insurance",
  "city": "New York"
},
  "test-customer-registration-processing-flow-invalid-phone-not-numeric": {
  "customerId": "CUST001",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "123456789A",
  "service": "Premium Insurance",
  "city": "New York"
},
  "test-customer-registration-processing-flow-invalid-phone-wrong-length": {
  "customerId": "CUST001",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "12345",
  "service": "Premium Insurance",
  "city": "New York"
},
  "test-customer-registration-processing-flow-missing-phone": {
  "customerId": "CUST001",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "service": "Premium Insurance",
  "city": "New York"
},
  "test-customer-registration-processing-flow-missing-service": {
  "customerId": "CUST001",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "1234567890",
  "city": "New York"
},
  "test-customer-registration-processing-flow-missing-city": {
  "customerId": "CUST001",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "1234567890",
  "service": "Premium Insurance"
},
  "test-customer-registration-processing-flow-duplicate-customer": {
  "customerId": "CUST001",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "1234567890",
  "service": "Premium Insurance",
  "city": "New York"
},
  "test-check-existing-customer-flow-no-records": {
  "customerId": "CUST999"
},
  "test-check-existing-customer-flow-record-found": {
  "customerId": "CUST001"
},
  "test-insert-new-customer-flow-success": {
  "customerId": "CUST100",
  "firstName": "Alice",
  "lastName": "Brown",
  "fullName": "ALICE BROWN",
  "email": "alice.brown@gmail.com",
  "emailDomain": "gmail.com",
  "phone": "5551112222",
  "city": "Boston",
  "service": "Standard Insurance",
  "customerType": "REGULAR"
}
}
