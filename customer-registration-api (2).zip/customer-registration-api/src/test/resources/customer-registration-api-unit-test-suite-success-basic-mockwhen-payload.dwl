%dw 2.0
output application/json
---
{
  "test-check-existing-customer-no-duplicate": {
    "salesforce:query": []
  },
  "test-insert-new-customer-success": {
    "salesforce:create": {
  items: [{
    id: '001ABC123456789',
    success: true
  }]
}
  }
}
