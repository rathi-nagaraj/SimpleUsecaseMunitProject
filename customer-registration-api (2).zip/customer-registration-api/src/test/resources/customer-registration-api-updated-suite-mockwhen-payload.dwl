%dw 2.0
output application/json
---
{
  "test-customer-registration-processing-flow-success": {
    "salesforce:query": [],
    "salesforce:create": {
  items: [{
    id: "001ABC123456789",
    successful: true
  }]
}
  },
  "test-customer-registration-processing-flow-vip-customer": {
    "salesforce:query": [],
    "salesforce:create": {
  items: [{
    id: "001VIP987654321",
    successful: true
  }]
}
  },
  "test-customer-registration-processing-flow-other-customer-type": {
    "salesforce:query": [],
    "salesforce:create": {
  items: [{
    id: "001OTH111222333",
    successful: true
  }]
}
  },
  "test-customer-registration-processing-flow-duplicate-customer": {
    "salesforce:query": [{
  Id: "001EXISTING123"
}]
  },
  "test-check-existing-customer-flow-no-records": {
    "salesforce:query": []
  },
  "test-check-existing-customer-flow-record-found": {
    "salesforce:query": [{
  Id: "001FOUND123456"
}]
  },
  "test-insert-new-customer-flow-success": {
    "salesforce:create": {
  items: [{
    id: "001INSERT123456",
    successful: true
  }]
}
  }
}
