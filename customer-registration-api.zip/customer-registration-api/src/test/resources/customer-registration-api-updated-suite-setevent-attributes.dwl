%dw 2.0
output application/json
---
{
  "customer-registration-api-main-test": readUrl('classpath://customerregistrationapimaintest/set-event_attributes.dwl', 'application/dw')
}
