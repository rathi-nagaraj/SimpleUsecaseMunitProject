%dw 2.0
output application/json
---
{
  "test-check-existing-customer-salesforce-connectivity-error": {
    "salesforce:query": {
        "typeId": "SALESFORCE:CONNECTIVITY",
        "cause": ""
      }
  },
  "test-insert-new-customer-salesforce-connectivity-error": {
    "salesforce:create": {
        "typeId": "SALESFORCE:CONNECTIVITY",
        "cause": ""
      }
  }
}
