%dw 2.0
output application/json
---
{
  "test-customer-registration-processing-flow-missing-customerId-error": {   "firstName": "John",   "lastName": "Doe",   "email": "john.doe@company.com",   "phone": "1234567890",   "city": "New York",   "service": "Premium" },
  "test-customer-registration-processing-flow-missing-firstName-error": {   "customerId": "CUST001",   "lastName": "Doe",   "email": "john.doe@company.com",   "phone": "1234567890",   "city": "New York",   "service": "Premium" },
  "test-customer-registration-processing-flow-missing-lastName-error": {   "customerId": "CUST001",   "firstName": "John",   "email": "john.doe@company.com",   "phone": "1234567890",   "city": "New York",   "service": "Premium" },
  "test-customer-registration-processing-flow-missing-email-error": {   "customerId": "CUST001",   "firstName": "John",   "lastName": "Doe",   "phone": "1234567890",   "city": "New York",   "service": "Premium" },
  "test-customer-registration-processing-flow-invalid-email-format-error": {   "customerId": "CUST001",   "firstName": "John",   "lastName": "Doe",   "email": "invalid-email",   "phone": "1234567890",   "city": "New York",   "service": "Premium" },
  "test-customer-registration-processing-flow-missing-phone-error": {   "customerId": "CUST001",   "firstName": "John",   "lastName": "Doe",   "email": "john.doe@company.com",   "city": "New York",   "service": "Premium" },
  "test-customer-registration-processing-flow-invalid-phone-length-error": {   "customerId": "CUST001",   "firstName": "John",   "lastName": "Doe",   "email": "john.doe@company.com",   "phone": "12345",   "city": "New York",   "service": "Premium" },
  "test-customer-registration-processing-flow-non-numeric-phone-error": {   "customerId": "CUST001",   "firstName": "John",   "lastName": "Doe",   "email": "john.doe@company.com",   "phone": "123456789a",   "city": "New York",   "service": "Premium" },
  "test-customer-registration-processing-flow-missing-service-error": {   "customerId": "CUST001",   "firstName": "John",   "lastName": "Doe",   "email": "john.doe@company.com",   "phone": "1234567890",   "city": "New York" },
  "test-customer-registration-processing-flow-missing-city-error": {   "customerId": "CUST001",   "firstName": "John",   "lastName": "Doe",   "email": "john.doe@company.com",   "phone": "1234567890",   "service": "Premium" },
  "test-customer-registration-processing-flow-duplicate-customer-error": {   "customerId": "CUST001",   "firstName": "John",   "lastName": "Doe",   "email": "john.doe@company.com",   "phone": "1234567890",   "city": "New York",   "service": "Premium" },
  "test-check-existing-customer-salesforce-connectivity-error": {   "customerId": "CUST001",   "firstName": "John",   "lastName": "Doe",   "email": "john.doe@company.com",   "phone": "1234567890",   "city": "New York",   "service": "Premium" },
  "test-insert-new-customer-salesforce-connectivity-error": {   "customerId": "CUST001",   "firstName": "John",   "lastName": "Doe",   "email": "john.doe@company.com",   "phone": "1234567890",   "city": "New York",   "service": "Premium",   "fullName": "JOHN DOE",   "emailDomain": "company.com",   "customerType": "VIP" }
}
