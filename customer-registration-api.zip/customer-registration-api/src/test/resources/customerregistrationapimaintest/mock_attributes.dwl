{
  "headers": {
    "accept": "application/json, text/plain, */*",
    "content-type": "application/json",
    "user-agent": "bruno-runtime/2.15.0",
    "request-start-time": "1780323613341",
    "content-length": "159",
    "accept-encoding": "gzip, compress, deflate, br",
    "host": "localhost:8081",
    "connection": "keep-alive"
  },
  "clientCertificate": null,
  "method": "POST",
  "scheme": "http",
  "queryParams": {},
  "requestUri": "/api/customer/create",
  "queryString": "",
  "version": "HTTP/1.1",
  "maskedRequestPath": "/customer/create",
  "listenerPath": "/api/*",
  "localAddress": "/127.0.0.1:8081",
  "relativePath": "/api/customer/create",
  "uriParams": {},
  "rawRequestUri": "/api/customer/create",
  "rawRequestPath": "/api/customer/create",
  "remoteAddress": "/127.0.0.1:56150",
  "requestPath": "/api/customer/create"
}