%dw 2.0
import * from dw::test::Asserts
---
payload must equalTo({
  "status": "SUCCESS",
  "transactionId": "e2df2755-72c6-4ca1-90df-b130359bec6a",
  "salesforceId": [
    "a01gK000016fEPdQAM"
  ]
})