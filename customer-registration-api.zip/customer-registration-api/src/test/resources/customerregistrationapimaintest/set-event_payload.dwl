{
  "customerId": "CUST1001",
  "firstName": "Bharani",
  "lastName": "kmrr",
  "email": "bhrnikmr8@gmail.com",
  "phone": "9876543210",
  "city": "Chennai"
}