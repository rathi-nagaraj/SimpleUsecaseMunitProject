%dw 2.0
output application/json
---
{
  "customer-registration-api-main-test": {
    "apikit:router": readUrl('classpath://customerregistrationapimaintest/mock_attributes.dwl', 'application/dw')
  }
}
