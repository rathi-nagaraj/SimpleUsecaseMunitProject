%dw 2.0
output application/json
---
{
  "test-customer-registration-success-path": {
  "customerId": "CUST001",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "1234567890",
  "city": "New York",
  "service": "Premium"
},
  "test-customer-registration-missing-customer-id": {
  "customerId": "",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "1234567890",
  "city": "New York",
  "service": "Premium"
},
  "test-customer-registration-missing-first-name": {
  "customerId": "CUST002",
  "firstName": "",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "1234567890",
  "city": "New York",
  "service": "Premium"
},
  "test-customer-registration-missing-last-name": {
  "customerId": "CUST003",
  "firstName": "John",
  "lastName": "",
  "email": "john.doe@gmail.com",
  "phone": "1234567890",
  "city": "New York",
  "service": "Premium"
},
  "test-customer-registration-invalid-email": {
  "customerId": "CUST004",
  "firstName": "John",
  "lastName": "Doe",
  "email": "invalid-email",
  "phone": "1234567890",
  "city": "New York",
  "service": "Premium"
},
  "test-customer-registration-missing-email": {
  "customerId": "CUST005",
  "firstName": "John",
  "lastName": "Doe",
  "email": "",
  "phone": "1234567890",
  "city": "New York",
  "service": "Premium"
},
  "test-customer-registration-invalid-phone-non-numeric": {
  "customerId": "CUST006",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "12345ABCDE",
  "city": "New York",
  "service": "Premium"
},
  "test-customer-registration-invalid-phone-length": {
  "customerId": "CUST007",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "12345",
  "city": "New York",
  "service": "Premium"
},
  "test-customer-registration-missing-phone": {
  "customerId": "CUST008",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "",
  "city": "New York",
  "service": "Premium"
},
  "test-customer-registration-missing-service": {
  "customerId": "CUST009",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "1234567890",
  "city": "New York",
  "service": ""
},
  "test-customer-registration-missing-city": {
  "customerId": "CUST010",
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@gmail.com",
  "phone": "1234567890",
  "city": "",
  "service": "Premium"
},
  "test-customer-registration-duplicate-customer": {
  "customerId": "CUST011",
  "firstName": "Jane",
  "lastName": "Smith",
  "email": "jane.smith@gmail.com",
  "phone": "9876543210",
  "city": "Boston",
  "service": "Standard"
},
  "test-customer-registration-vip-customer-type": {
  "customerId": "CUST012",
  "firstName": "Alice",
  "lastName": "Johnson",
  "email": "alice.johnson@company.com",
  "phone": "5551234567",
  "city": "San Francisco",
  "service": "Enterprise"
},
  "test-customer-registration-other-customer-type": {
  "customerId": "CUST013",
  "firstName": "Bob",
  "lastName": "Wilson",
  "email": "bob.wilson@othermail.org",
  "phone": "4445556666",
  "city": "Chicago",
  "service": "Basic"
},
  "test-check-existing-customer-flow": {
  "customerId": "CUST999"
},
  "test-insert-new-customer-flow": {
  "customerId": "CUST888",
  "firstName": "Test",
  "lastName": "User",
  "fullName": "TEST USER",
  "email": "test.user@test.com",
  "emailDomain": "test.com",
  "phone": "9998887777",
  "city": "Seattle",
  "service": "Test Service",
  "customerType": "OTHER"
}
}
