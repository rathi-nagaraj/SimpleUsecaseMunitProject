%dw 2.0
output application/json
---
{
  "customer-registration-api-main-test": readUrl('classpath://customerregistrationapimaintest/set-event_payload.dwl', 'application/dw'),
  "check-existing-customer-success-test": {   customerId: "C001" },
  "check-existing-customer-not-found-test": {   customerId: "C999" },
  "insert-new-customer-success-test": {   customerId: "C001",   firstName: "John",   lastName: "Doe",   fullName: "JOHN DOE",   email: "john.doe@gmail.com",   emailDomain: "gmail.com",   phone: "1234567890",   city: "New York",   service: "Premium",   customerType: "REGULAR" },
  "customer-registration-processing-flow-success-test": {   customerId: "C001",   firstName: "John",   lastName: "Doe",   email: "john.doe@gmail.com",   phone: "1234567890",   city: "New York",   service: "Premium" },
  "customer-registration-processing-flow-missing-customerId-test": {   firstName: "John",   lastName: "Doe",   email: "john.doe@gmail.com",   phone: "1234567890",   city: "New York",   service: "Premium" },
  "customer-registration-processing-flow-missing-firstName-test": {   customerId: "C001",   lastName: "Doe",   email: "john.doe@gmail.com",   phone: "1234567890",   city: "New York",   service: "Premium" },
  "customer-registration-processing-flow-missing-lastName-test": {   customerId: "C001",   firstName: "John",   email: "john.doe@gmail.com",   phone: "1234567890",   city: "New York",   service: "Premium" },
  "customer-registration-processing-flow-invalid-email-test": {   customerId: "C001",   firstName: "John",   lastName: "Doe",   email: "invalid-email",   phone: "1234567890",   city: "New York",   service: "Premium" },
  "customer-registration-processing-flow-missing-email-test": {   customerId: "C001",   firstName: "John",   lastName: "Doe",   phone: "1234567890",   city: "New York",   service: "Premium" },
  "customer-registration-processing-flow-invalid-phone-length-test": {   customerId: "C001",   firstName: "John",   lastName: "Doe",   email: "john.doe@gmail.com",   phone: "12345",   city: "New York",   service: "Premium" },
  "customer-registration-processing-flow-non-numeric-phone-test": {   customerId: "C001",   firstName: "John",   lastName: "Doe",   email: "john.doe@gmail.com",   phone: "123ABC7890",   city: "New York",   service: "Premium" },
  "customer-registration-processing-flow-missing-service-test": {   customerId: "C001",   firstName: "John",   lastName: "Doe",   email: "john.doe@gmail.com",   phone: "1234567890",   city: "New York" },
  "customer-registration-processing-flow-missing-city-test": {   customerId: "C001",   firstName: "John",   lastName: "Doe",   email: "john.doe@gmail.com",   phone: "1234567890",   service: "Premium" },
  "customer-registration-processing-flow-duplicate-customer-test": {   customerId: "C001",   firstName: "John",   lastName: "Doe",   email: "john.doe@gmail.com",   phone: "1234567890",   city: "New York",   service: "Premium" },
  "customer-registration-processing-flow-vip-customer-test": {   customerId: "C002",   firstName: "Jane",   lastName: "Smith",   email: "jane.smith@company.com",   phone: "9876543210",   city: "Los Angeles",   service: "Premium" },
  "customer-registration-processing-flow-other-customer-type-test": {   customerId: "C003",   firstName: "Bob",   lastName: "Johnson",   email: "bob.johnson@example.org",   phone: "5555555555",   city: "Chicago",   service: "Standard" }
}
