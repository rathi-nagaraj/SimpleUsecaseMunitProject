%dw 2.0
output application/json
---
{
  "test-customer-registration-processing-flow-success-regular-customer": {
  customerId: "CUST001",
  firstName: "John",
  lastName: "Doe",
  email: "john.doe@gmail.com",
  phone: "9876543210",
  city: "New York",
  service: "Premium Support"
},
  "test-customer-registration-processing-flow-success-vip-customer": {
  customerId: "CUST002",
  firstName: "Jane",
  lastName: "Smith",
  email: "jane.smith@company.com",
  phone: "1234567890",
  city: "Los Angeles",
  service: "Enterprise Support"
},
  "test-customer-registration-processing-flow-success-other-customer": {
  customerId: "CUST003",
  firstName: "Robert",
  lastName: "Johnson",
  email: "robert.johnson@example.org",
  phone: "5551234567",
  city: "Chicago",
  service: "Standard Support"
},
  "test-check-existing-customer-no-duplicate-found": {
  customerId: "CUST999"
},
  "test-insert-new-customer-success": {
  customerId: "CUST100",
  firstName: "Alice",
  lastName: "Williams",
  fullName: "ALICE WILLIAMS",
  email: "alice.williams@test.com",
  emailDomain: "test.com",
  phone: "9998887777",
  city: "Boston",
  service: "Basic Support",
  customerType: "OTHER"
},
  "test-post-customer-create-endpoint-success": {
  customerId: "CUST200",
  firstName: "Michael",
  lastName: "Brown",
  email: "michael.brown@gmail.com",
  phone: "7778889999",
  city: "Seattle",
  service: "Premium Support"
}
}
