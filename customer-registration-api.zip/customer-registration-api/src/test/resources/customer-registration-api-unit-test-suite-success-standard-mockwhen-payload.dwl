%dw 2.0
output application/json
---
{
  "test-customer-registration-processing-flow-success-regular-customer": {
    "salesforce:query": [],
    "salesforce:create": {
  items: [{
    id: "a015j00000ABCDEFGHI123",
    success: true
  }]
}
  },
  "test-customer-registration-processing-flow-success-vip-customer": {
    "salesforce:query": [],
    "salesforce:create": {
  items: [{
    id: "a015j00000VIPVIPVIP456",
    success: true
  }]
}
  },
  "test-customer-registration-processing-flow-success-other-customer": {
    "salesforce:query": [],
    "salesforce:create": {
  items: [{
    id: "a015j00000OTHOTHOTH789",
    success: true
  }]
}
  },
  "test-check-existing-customer-no-duplicate-found": {
    "salesforce:query": []
  },
  "test-insert-new-customer-success": {
    "salesforce:create": {
  items: [{
    id: "a015j00000NEWCUSTOMER",
    success: true
  }]
}
  },
  "test-post-customer-create-endpoint-success": {
    "salesforce:query": [],
    "salesforce:create": {
  items: [{
    id: "a015j00000ENDPOINT123",
    success: true
  }]
}
  }
}
