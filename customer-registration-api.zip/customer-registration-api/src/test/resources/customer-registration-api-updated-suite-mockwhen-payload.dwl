%dw 2.0
output application/json
---
{
  "test-customer-registration-success-path": {
    "salesforce:query": [],
    "salesforce:create": {
  items: [
    {
      id: '001ABC123456789',
      success: true
    }
  ]
}
  },
  "test-customer-registration-duplicate-customer": {
    "salesforce:query": [
  {
    Id: '001ABC123456789'
  }
]
  },
  "test-customer-registration-vip-customer-type": {
    "salesforce:query": [],
    "salesforce:create": {
  items: [
    {
      id: '001VIP987654321',
      success: true
    }
  ]
}
  },
  "test-customer-registration-other-customer-type": {
    "salesforce:query": [],
    "salesforce:create": {
  items: [
    {
      id: '001OTH111222333',
      success: true
    }
  ]
}
  },
  "test-check-existing-customer-flow": {
    "salesforce:query": [
  {
    Id: '001TEST123456789'
  }
]
  },
  "test-insert-new-customer-flow": {
    "salesforce:create": {
  items: [
    {
      id: '001NEW987654321',
      success: true
    }
  ]
}
  }
}
