%dw 2.0
output application/json
---
{
  "customer-registration-api-main-test": {
    "apikit:router": readUrl('classpath://customerregistrationapimaintest/mock_payload.dwl', 'application/dw')
  },
  "check-existing-customer-success-test": {
    "salesforce:query": [{   Id: "001ABC123456789" }]
  },
  "check-existing-customer-not-found-test": {
    "salesforce:query": []
  },
  "insert-new-customer-success-test": {
    "salesforce:create": {   items: [{     id: "001ABC123456789",     success: true   }] }
  },
  "customer-registration-processing-flow-success-test": {
    "salesforce:query": [],
    "salesforce:create": {   items: [{     id: "001ABC123456789",     success: true   }] }
  },
  "customer-registration-processing-flow-duplicate-customer-test": {
    "salesforce:query": [{   Id: "001XYZ987654321" }]
  },
  "customer-registration-processing-flow-vip-customer-test": {
    "salesforce:query": [],
    "salesforce:create": {   items: [{     id: "001VIP987654321",     success: true   }] }
  },
  "customer-registration-processing-flow-other-customer-type-test": {
    "salesforce:query": [],
    "salesforce:create": {   items: [{     id: "001OTH555666777",     success: true   }] }
  }
}
